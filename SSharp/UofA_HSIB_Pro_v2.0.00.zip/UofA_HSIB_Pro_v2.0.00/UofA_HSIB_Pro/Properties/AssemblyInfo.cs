﻿using System.Reflection;

[assembly: AssemblyTitle("UofA_HSIB_Pro")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("UofA_HSIB_Pro")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyVersion("1.0.0.*")]

