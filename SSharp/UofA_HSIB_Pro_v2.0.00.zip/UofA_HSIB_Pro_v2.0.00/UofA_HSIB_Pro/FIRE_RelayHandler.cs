﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;

namespace UofA_HSIB_Pro
{
    public class FIRE_RelayHandler
    {
    }
}